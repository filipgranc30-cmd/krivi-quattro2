import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Simplified for Vercel
};

export default nextConfig;
