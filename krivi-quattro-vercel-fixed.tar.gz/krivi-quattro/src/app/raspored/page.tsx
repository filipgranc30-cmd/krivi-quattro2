export default function Raspored() {
  const turniri = [
    { datum: '05-06.12.2026.', naziv: '2. PSGZ Masters + Kup skupina D', mjesto: 'Sports bar Amarena', status: 'Najavljeno' },
    { datum: '12.12.2026.', naziv: 'Božićni open', mjesto: 'Sesvete', status: 'Uskoro' },
    { datum: '19.12.2026.', naziv: 'Ligaški turnir 3.B', mjesto: 'Buzin', status: 'Planirano' },
  ];

  return (
    <div className="min-h-screen bg-black text-white pb-20 p-4">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-xs">GRB</div>
        <div>
          <div className="text-2xl font-bold">Raspored turnira</div>
          <div className="text-sm text-orange-400">PK Krivi Quattro</div>
        </div>
      </div>

      <div className="space-y-3">
        {turniri.map((t, i) => (
          <div key={i} className="p-4 border border-orange-500 rounded-xl">
            <div className="font-bold text-orange-400">{t.datum}</div>
            <div className="text-lg">{t.naziv}</div>
            <div className="text-sm text-gray-400">{t.mjesto}</div>
            <div className="text-xs mt-1 text-orange-300">{t.status}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
