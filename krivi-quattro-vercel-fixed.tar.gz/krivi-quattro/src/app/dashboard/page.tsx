export default function Dashboard() {
  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="p-4 flex items-center gap-3 border-b border-gray-800">
        <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold">
          GRB
        </div>
        <div>
          <div className="text-xl font-bold">KRIVI QUATTRO</div>
          <div className="text-xs text-gray-400">DARTS CLUB</div>
        </div>
      </div>

      {/* League position */}
      <div className="mx-4 mt-4 p-3 bg-orange-600 rounded-xl flex items-center gap-2">
        <span>🏆</span>
        <span className="font-bold">3. B LIGA - 10. MJESTO</span>
      </div>

      {/* Next match */}
      <div className="mx-4 mt-4 p-4 border border-gray-700 rounded-xl">
        <div className="text-sm text-gray-400 mb-2">SLJEDEĆA UTAKMICA</div>
        <div className="text-center text-3xl font-bold text-orange-400 my-4">BULL BUZIN</div>
        <div className="text-center text-sm text-gray-400">Darts Pub Buzin</div>
        
        <div className="mt-6 text-sm font-bold text-orange-400">NAJBOLJI IGRAČI (PROSJEK)</div>
        <div className="mt-2 space-y-2 text-sm">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="flex justify-between">
              <span>{i}. Igrač {i}</span>
              <span className="text-orange-400">30.{10-i}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom nav placeholder */}
      <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 p-2 grid grid-cols-4 text-center text-xs">
        <div className="text-orange-400">Naslovnica</div>
        <div>Ljestvice</div>
        <div>Rezultati</div>
        <div>Više</div>
      </div>
    </div>
  );
}
