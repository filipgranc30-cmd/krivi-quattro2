export default function Login() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-4xl font-bold text-orange-400">KRIVI QUATTRO</div>
          <div className="text-sm text-gray-400 mt-1">DARTS CLUB</div>
        </div>
        <form className="space-y-4">
          <input
            type="email"
            placeholder="E-mail"
            className="w-full p-4 bg-gray-900 border border-orange-500 rounded-xl text-white"
          />
          <input
            type="password"
            placeholder="Lozinka"
            className="w-full p-4 bg-gray-900 border border-orange-500 rounded-xl text-white"
          />
          <button className="w-full p-4 bg-orange-500 hover:bg-orange-600 rounded-xl font-bold text-black">
            Prijava
          </button>
        </form>
      </div>
    </div>
  );
}
