export default function Trening() {
  const games = ['501', 'CRICKET', 'CRAZY CRICKET', 'MARATON', 'OSTALE CYBERDINE'];
  const days = ['PON', 'UTO', 'SRE', 'ČET', 'PET', 'SUB', 'NED'];

  return (
    <div className="min-h-screen bg-black text-white pb-20 p-4">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-xs">GRB</div>
        <div>
          <div className="text-2xl font-bold">Trening</div>
          <div className="text-sm text-orange-400">PK Krivi Quattro</div>
        </div>
      </div>

      <div className="text-sm font-bold text-orange-400 mb-3">ODABERI IGRE</div>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {games.map(game => (
          <div key={game} className="p-4 border border-orange-500 rounded-xl text-center">
            {game}
          </div>
        ))}
      </div>

      <div className="text-sm font-bold text-orange-400 mb-3">ODABERI DAN</div>
      <div className="flex gap-2 overflow-x-auto mb-6">
        {days.map(day => (
          <div key={day} className="px-4 py-3 border border-gray-700 rounded-xl text-center min-w-[60px]">
            {day}
          </div>
        ))}
      </div>

      <div className="p-4 border border-orange-500 rounded-xl">
        <div className="font-bold text-orange-400">TRENING STATISTIKA</div>
        <div className="text-sm text-gray-400 mt-1">Pregledaj rang listu unutar kluba</div>
      </div>
    </div>
  );
}
